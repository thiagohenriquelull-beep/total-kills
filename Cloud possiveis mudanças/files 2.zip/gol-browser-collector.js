/*
  Coletor V2 para rodar no navegador do Codex ja logado no GOL.

  Mudanças vs V1:
  - Extrai duração do jogo (gameDuration em segundos)
  - Extrai gold, towers, dragons, barons por time
  - Calcula killsPerMin (kills totais / duração em minutos)
  - Função enrichExistingGames() para enriquecer jogos antigos
  - Versão do coletor: expanded-2026-2

  Entrada esperada:
  - global `tab` disponivel pelo Browser plugin.
  - sessao logada no https://gol.gg/.

  Saida:
  - objeto com `games`.
*/

const GOL_COLLECTOR_VERSION = "expanded-2026-2";
const GOL_DEFAULT_TARGET_PER_LEAGUE = 300;
const GOL_DEFAULT_MIN_PER_LEAGUE = 250;

const GOL_LEAGUE_RULES = {
  LCK: {
    include: [/^LCK 20\d{2}\b/i],
    exclude: [/\bCL\b/i],
  },
  LPL: {
    include: [/^LPL 20\d{2}\b/i],
    exclude: [],
  },
  CBLOL: {
    include: [/^CBLOL\b/i],
    exclude: [],
  },
  LEC: {
    include: [/^LEC\b/i],
    exclude: [],
  },
  LCS: {
    include: [/^LCS\b/i],
    exclude: [/^NACL\b/i],
  },
};

function encodeTournament(name) {
  return encodeURIComponent(name).replace(/%20/g, "%20");
}

function parseSeasonYear(season) {
  const value = String(season || "").replace(/^S/i, "");
  const number = Number(value);
  return Number.isFinite(number) ? 2010 + number : "";
}

function detectStage(tournament) {
  const name = String(tournament || "");
  if (/playoffs|finals|grand finals|regional finals|play-in/i.test(name)) return "playoffs";
  if (/cup|lock-in|kickoff/i.test(name)) return "cup";
  if (/placements|qualifier/i.test(name)) return "qualifier";
  return "regular";
}

function tournamentMatchesLeague(league, tournament) {
  const rules = GOL_LEAGUE_RULES[league];
  if (!rules) return false;
  return rules.include.some((rule) => rule.test(tournament)) && !rules.exclude.some((rule) => rule.test(tournament));
}

function sortTournamentsRecentFirst(a, b) {
  const stageScore = (name) => {
    if (/playoffs|finals|grand finals|regional finals|play-in/i.test(name)) return 3;
    if (/split 3|rounds 3-5|summer|championship/i.test(name)) return 2;
    if (/split 2|spring|rounds 1-2/i.test(name)) return 1;
    return 0;
  };
  return stageScore(b) - stageScore(a) || b.localeCompare(a, undefined, { numeric: true });
}

function parseTeamId(url) {
  const match = String(url || "").match(/team-(?:stats|matchlist)\/(\d+)\//);
  return match ? match[1] : "";
}

function uniqueBy(items, keyFn) {
  const seen = new Set();
  const out = [];
  for (const item of items) {
    const key = keyFn(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

async function waitPage(tab) {
  await tab.playwright.waitForLoadState({ state: "domcontentloaded", timeoutMs: 12000 }).catch(() => {});
}

async function discoverTournamentsForSeason(tab, season) {
  const url = `https://gol.gg/teams/list/season-${season}/split-ALL/tournament-ALL/`;
  await tab.goto(url);
  await waitPage(tab);

  return tab.playwright.evaluate(() => {
    return Array.from(document.querySelectorAll("select option"))
      .map((option) => option.innerText.trim().replace(/\s+/g, " "))
      .filter(Boolean);
  }, undefined, { timeoutMs: 10000 });
}

async function discoverLeagueTournamentPlan(tab, options = {}) {
  const seasons = options.seasons || ["S16"];
  const leagues = options.leagues || Object.keys(GOL_LEAGUE_RULES);
  const plan = {};
  const discovered = {};

  for (const season of seasons) {
    const tournaments = await discoverTournamentsForSeason(tab, season);
    discovered[season] = tournaments;
    for (const league of leagues) {
      const matching = tournaments
        .filter((tournament) => tournamentMatchesLeague(league, tournament))
        .sort(sortTournamentsRecentFirst);
      if (!plan[league]) plan[league] = [];
      for (const tournament of matching) {
        plan[league].push({
          season,
          seasonYear: parseSeasonYear(season),
          league,
          tournament,
          stage: detectStage(tournament),
        });
      }
    }
  }

  return { plan, discovered };
}

async function collectTeamsForTournament(tab, item) {
  const url = `https://gol.gg/teams/list/season-${item.season}/split-ALL/tournament-${encodeTournament(item.tournament)}/`;
  await tab.goto(url);
  await waitPage(tab);

  return tab.playwright.evaluate(() => {
    return Array.from(document.querySelectorAll('table a[href*="team-stats"]'))
      .map((a) => ({ name: a.innerText.trim().replace(/\s+/g, " "), href: a.href }))
      .filter((team) => team.name && /team-stats\/\d+\//.test(team.href));
  }, undefined, { timeoutMs: 10000 });
}

async function collectMatchLinksForTeam(tab, team, item) {
  const teamId = parseTeamId(team.href);
  if (!teamId) return [];

  const url = `https://gol.gg/teams/team-matchlist/${teamId}/split-ALL/tournament-${encodeTournament(item.tournament)}/`;
  await tab.goto(url);
  await waitPage(tab);

  return tab.playwright.evaluate((arg) => {
    return Array.from(document.querySelectorAll("table tr"))
      .map((tr) => {
        const cells = Array.from(tr.querySelectorAll("th,td")).map((td) => td.innerText.trim().replace(/\s+/g, " "));
        const link = tr.querySelector('a[href*="/game/stats/"]');
        if (!link || cells.length < 14) return null;
        return {
          league: arg.league,
          season: arg.season,
          seasonYear: arg.seasonYear,
          tournament: arg.tournament,
          sourceTournament: arg.tournament,
          stage: arg.stage,
          focalTeam: arg.teamName,
          focalTeamId: arg.teamId,
          url: link.href,
          id: (link.href.match(/game\/stats\/(\d+)\//) || [])[1] || "",
          gameLabel: cells[13] || link.innerText.trim().replace(/\s+/g, " "),
          patch: cells[14] || "",
          week: cells[15] || "",
        };
      })
      .filter(Boolean);
  }, { ...item, teamName: team.name, teamId }, { timeoutMs: 10000 });
}

/**
 * V2: extrai duração, gold, towers, dragons, barons além de kills e picks.
 *
 * Na página page-game do GOL, abaixo de cada "Team - WIN/LOSS" aparecem
 * números na ordem: kills, deaths, assists, gold, towers, inhibitors, barons, dragons, heralds.
 * A duração aparece como "mm:ss" em algum ponto da página.
 */
async function collectGameDetails(tab, candidate) {
  await tab.goto(candidate.url);
  await waitPage(tab);

  return tab.playwright.evaluate((candidate) => {
    const lines = document.body.innerText.split("\n").map((line) => line.trim()).filter(Boolean);
    const title = document.querySelector("h1")?.innerText?.trim() || candidate.gameLabel;
    const teamLinks = [];

    for (const a of document.querySelectorAll('a[href*="/teams/team-stats/"]')) {
      const name = a.innerText.trim().replace(/\s+/g, " ");
      const id = (a.href.match(/team-stats\/(\d+)\//) || [])[1] || "";
      if (name && id && !teamLinks.some((team) => team.id === id)) teamLinks.push({ name, id });
      if (teamLinks.length >= 2) break;
    }

    const teamA = teamLinks[0]?.name || (title.split(" vs ")[0] || "").trim();
    const teamB = teamLinks[1]?.name || ((title.split(" vs ")[1] || "").replace(/\s+game\s+\d+.*/i, "").trim());
    const findTeamIndex = (team) => lines.findIndex((line) => line === `${team} - WIN` || line === `${team} - LOSS`);
    const teamAIndex = findTeamIndex(teamA);
    const teamBIndex = findTeamIndex(teamB);

    // Extrair sequência de stats numéricos após cada time
    function extractTeamStats(startIndex) {
      if (startIndex < 0) return [];
      const stats = [];
      for (let i = startIndex + 1; i < Math.min(startIndex + 20, lines.length); i++) {
        if (/- WIN$|- LOSS$/.test(lines[i])) break;
        const cleaned = lines[i].replace(/[,.\s]/g, "");
        if (/^\d+$/.test(cleaned)) {
          stats.push(Number(cleaned));
        }
      }
      return stats;
    }

    const statsA = extractTeamStats(teamAIndex);
    const statsB = extractTeamStats(teamBIndex);

    const killsA = statsA[0] ?? NaN;
    const killsB = statsB[0] ?? NaN;
    const goldA = statsA.length >= 4 ? statsA[3] : NaN;
    const goldB = statsB.length >= 4 ? statsB[3] : NaN;
    const towersA = statsA.length >= 5 ? statsA[4] : NaN;
    const towersB = statsB.length >= 5 ? statsB[4] : NaN;
    const baronsA = statsA.length >= 7 ? statsA[6] : NaN;
    const baronsB = statsB.length >= 7 ? statsB[6] : NaN;
    const dragonsA = statsA.length >= 8 ? statsA[7] : NaN;
    const dragonsB = statsB.length >= 8 ? statsB[7] : NaN;

    // Duração: buscar padrão mm:ss
    let gameDurationSeconds = NaN;
    const durationLine = lines.find((line) => /^\d{1,3}:\d{2}$/.test(line));
    if (durationLine) {
      const [minutes, seconds] = durationLine.split(":").map(Number);
      gameDurationSeconds = minutes * 60 + seconds;
    }

    const patchLine = lines.find((line) => /^v\d+\.\d+/.test(line)) || `v${candidate.patch || ""}`;
    const dateLine = lines.find((line) => /^20\d{2}-\d{2}-\d{2}/.test(line)) || "";
    const tournamentLine = lines.find((line) => /2026|2025/.test(line) && /\(/.test(line) && !/^20\d{2}-/.test(line)) || candidate.tournament;
    const playerTables = Array.from(document.querySelectorAll("table.playersInfosLine"));
    const tablePicks = playerTables.map((table) => {
      return Array.from(table.querySelectorAll('a[href*="champion-stats"] img'))
        .map((img) => img.alt)
        .filter(Boolean)
        .slice(0, 5);
    });

    const totalKills = Number.isFinite(killsA) && Number.isFinite(killsB) ? killsA + killsB : NaN;
    const durationMinutes = Number.isFinite(gameDurationSeconds) ? gameDurationSeconds / 60 : NaN;
    const killsPerMin = Number.isFinite(totalKills) && durationMinutes > 0
      ? Math.round((totalKills / durationMinutes) * 100) / 100 : NaN;

    return {
      id: candidate.id,
      league: candidate.league,
      tournament: candidate.tournament,
      season: candidate.season,
      seasonYear: candidate.seasonYear,
      stage: candidate.stage || "",
      sourceTournament: candidate.sourceTournament || candidate.tournament,
      tournamentLine,
      date: dateLine.split(" ")[0] || "",
      week: candidate.week || (dateLine.match(/\(([^)]+)\)/) || [])[1] || "",
      patch: patchLine.replace(/^v/i, ""),
      game: title,
      sourceUrl: candidate.url,
      teamA,
      teamB,
      teamAId: teamLinks[0]?.id || "",
      teamBId: teamLinks[1]?.id || "",
      killsA,
      killsB,
      totalKills,
      gameDuration: Number.isFinite(gameDurationSeconds) ? gameDurationSeconds : null,
      killsPerMin: Number.isFinite(killsPerMin) ? killsPerMin : null,
      goldA: Number.isFinite(goldA) ? goldA : null,
      goldB: Number.isFinite(goldB) ? goldB : null,
      towersA: Number.isFinite(towersA) ? towersA : null,
      towersB: Number.isFinite(towersB) ? towersB : null,
      dragonsA: Number.isFinite(dragonsA) ? dragonsA : null,
      dragonsB: Number.isFinite(dragonsB) ? dragonsB : null,
      baronsA: Number.isFinite(baronsA) ? baronsA : null,
      baronsB: Number.isFinite(baronsB) ? baronsB : null,
      collectedAt: new Date().toISOString(),
      collectorVersion: GOL_COLLECTOR_VERSION,
      picks: {
        teamA: tablePicks[0] || [],
        teamB: tablePicks[1] || [],
      },
    };
  }, candidate, { timeoutMs: 10000 });
}

function isValidGame(game) {
  return Boolean(
    game
      && game.id
      && game.league
      && game.teamA
      && game.teamB
      && game.date
      && Number.isFinite(game.totalKills)
      && game.picks?.teamA?.length === 5
      && game.picks?.teamB?.length === 5
  );
}

async function collectGolKillsDataset(tab, options = {}) {
  const maxPerLeague = options.maxPerLeague || options.targetPerLeague || GOL_DEFAULT_TARGET_PER_LEAGUE;
  const minPerLeague = options.minPerLeague || GOL_DEFAULT_MIN_PER_LEAGUE;
  const tournamentPlan = options.tournamentPlan || (await discoverLeagueTournamentPlan(tab, { seasons: ["S16"], ...options })).plan;
  const collectedGames = [];
  const report = [];

  for (const [league, tournaments] of Object.entries(tournamentPlan)) {
    let candidates = [];
    let teamsSeen = 0;
    const leagueGames = [];
    const seenGames = new Set();
    const tournamentReports = [];

    for (const item of tournaments) {
      if (leagueGames.length >= maxPerLeague) break;
      const teams = uniqueBy(await collectTeamsForTournament(tab, item), (team) => parseTeamId(team.href));
      teamsSeen += teams.length;
      for (const team of teams) {
        candidates.push(...await collectMatchLinksForTeam(tab, team, item));
      }

      const itemCandidates = uniqueBy(candidates, (candidate) => candidate.id)
        .filter((candidate) => !seenGames.has(String(candidate.id)))
        .sort((a, b) => Number(b.id) - Number(a.id))
        .slice(0, maxPerLeague - leagueGames.length);

      let validFromTournament = 0;
      for (const candidate of itemCandidates) {
        const game = await collectGameDetails(tab, candidate);
        seenGames.add(String(candidate.id));
        if (isValidGame(game)) {
          validFromTournament += 1;
          game.stage = game.stage || item.stage;
          game.sourceTournament = game.sourceTournament || item.tournament;
          leagueGames.push(game);
        }
        if (leagueGames.length >= maxPerLeague) break;
      }

      tournamentReports.push({
        league,
        season: item.season,
        tournament: item.tournament,
        stage: item.stage,
        teams: teams.length,
        candidates: itemCandidates.length,
        validGames: validFromTournament,
        cumulativeGames: leagueGames.length,
      });

      if (leagueGames.length >= maxPerLeague) break;
    }

    collectedGames.push(...leagueGames);
    report.push({
      league,
      teamsSeen,
      candidates: uniqueBy(candidates, (candidate) => candidate.id).length,
      games: leagueGames.length,
      target: maxPerLeague,
      minimum: minPerLeague,
      tournaments: tournamentReports,
    });
  }

  collectedGames.sort((a, b) => a.league.localeCompare(b.league) || Number(b.id) - Number(a.id));
  return {
    meta: {
      source: "GOL logged session",
      createdAt: new Date().toISOString(),
      collectorVersion: GOL_COLLECTOR_VERSION,
      maxPerLeague,
      minPerLeague,
      report,
      modelFields: ["totalKills", "gameDuration", "killsPerMin", "goldA", "goldB", "towersA", "towersB", "dragonsA", "dragonsB", "baronsA", "baronsB"],
    },
    games: collectedGames,
  };
}

/**
 * Enriquecimento: visita jogos já coletados que não têm gameDuration
 * e adiciona os campos novos sem recoletar tudo.
 *
 * Uso no Codex:
 *   const fs = await import("node:fs/promises");
 *   const data = JSON.parse(await fs.readFile("data/expanded-LCK.json", "utf8"));
 *   const result = await enrichExistingGames(tab, data.games);
 *   await fs.writeFile("data/expanded-LCK.json", JSON.stringify(data, null, 2), "utf8");
 */
async function enrichExistingGames(tab, games, options = {}) {
  const batchSize = options.batchSize || 50;
  const needsEnrichment = games.filter((g) => g.gameDuration == null);
  console.log(`${needsEnrichment.length} jogos precisam de enriquecimento (de ${games.length} total).`);

  let enriched = 0;
  let failed = 0;

  for (let i = 0; i < needsEnrichment.length; i++) {
    const game = needsEnrichment[i];
    try {
      const candidate = {
        id: game.id,
        url: game.sourceUrl,
        league: game.league,
        patch: game.patch,
        tournament: game.tournament,
        season: game.season,
        seasonYear: game.seasonYear,
        stage: game.stage,
        sourceTournament: game.sourceTournament,
      };
      const fresh = await collectGameDetails(tab, candidate);

      if (fresh.gameDuration != null) {
        game.gameDuration = fresh.gameDuration;
        game.killsPerMin = fresh.killsPerMin;
        game.goldA = fresh.goldA;
        game.goldB = fresh.goldB;
        game.towersA = fresh.towersA;
        game.towersB = fresh.towersB;
        game.dragonsA = fresh.dragonsA;
        game.dragonsB = fresh.dragonsB;
        game.baronsA = fresh.baronsA;
        game.baronsB = fresh.baronsB;
        game.collectorVersion = GOL_COLLECTOR_VERSION;
        enriched++;
      } else {
        failed++;
      }
    } catch (err) {
      console.warn(`Erro ao enriquecer jogo ${game.id}: ${err.message}`);
      failed++;
    }

    if ((i + 1) % batchSize === 0) {
      console.log(`Progresso: ${i + 1}/${needsEnrichment.length} (${enriched} ok, ${failed} falhas)`);
    }
  }

  console.log(`Enriquecimento concluído: ${enriched} ok, ${failed} falhas de ${needsEnrichment.length}`);
  return { enriched, failed, total: games.length };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    GOL_COLLECTOR_VERSION,
    GOL_LEAGUE_RULES,
    discoverLeagueTournamentPlan,
    collectGolKillsDataset,
    collectTeamsForTournament,
    collectMatchLinksForTeam,
    collectGameDetails,
    enrichExistingGames,
    isValidGame,
    detectStage,
    tournamentMatchesLeague,
    uniqueBy,
    parseTeamId,
  };
}
