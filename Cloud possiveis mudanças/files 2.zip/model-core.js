(function attachModel(root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.GOLPredictorModel = api;
})(typeof globalThis !== "undefined" ? globalThis : window, function factory() {
  const TARGET_LEAGUES = ["LCK", "LPL", "CBLOL", "LEC", "LCS"];
  const ROLES = ["TOP", "JUNGLE", "MID", "ADC", "SUP"];
  const DEFAULT_SIGMA = 6.4;

  const DEFAULT_OPTIONS = {
    calibrationWindow: 15,
    offsetWeight: 0.85,
    offsetShrink: 8,
    offsetCap: 5,
    globalOffsetWeight: 0.55,
    globalOffsetShrink: 25,
    globalOffsetCap: 3,
    leagueRecentWeight: 0.9,
    leagueHalfLife: 7,
    patchWeight: 0.06,
    patchShrink: 18,
    patchCap: 1.6,
    teamWeight: 0.45,
    teamWindow: 24,
    teamHalfLife: 5,
    teamShrink: 14,
    teamCap: 2.4,
    champWeight: 1,
    draftWeight: 0,
    champShrink: 28,
    champCap: 1.5,
    draftCap: 2.2,
    // V2: duração e ritmo
    durationWeight: 0.4,
    durationShrink: 10,
    durationCap: 3.0,
    kpmWeight: 0.3,
    kpmShrink: 10,
    kpmCap: 2.0,
  };

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function mean(values) {
    return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
  }

  function std(values) {
    if (values.length < 2) return DEFAULT_SIGMA;
    const avg = mean(values);
    const variance = mean(values.map((value) => (value - avg) ** 2));
    return Math.max(3.5, Math.sqrt(variance));
  }

  function shrink(n, k) {
    return n / (n + k);
  }

  function sortRecent(a, b) {
    const dateCompare = String(b.date || "").localeCompare(String(a.date || ""));
    if (dateCompare !== 0) return dateCompare;
    return Number(b.id || 0) - Number(a.id || 0);
  }

  function weightedMean(gamesOrValues, getValue, halfLife) {
    const values = gamesOrValues.map((item, index) => {
      const value = getValue(item);
      const weight = Math.pow(0.5, index / halfLife);
      return { value, weight };
    }).filter((item) => Number.isFinite(item.value));
    const weightSum = values.reduce((sum, item) => sum + item.weight, 0);
    if (!weightSum) return 0;
    return values.reduce((sum, item) => sum + item.value * item.weight, 0) / weightSum;
  }

  function addSample(map, key, value) {
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(value);
  }

  function addTotalSample(residualMap, totalMap, key, residual, totalKills) {
    addSample(residualMap, key, residual);
    addSample(totalMap, key, totalKills);
  }

  function getAllPicks(game) {
    return [...(game.picks?.teamA || []), ...(game.picks?.teamB || [])].filter(Boolean);
  }

  function normalizeOptions(options) {
    return { ...DEFAULT_OPTIONS, ...(options || {}) };
  }

  function buildRawIndex(games, options) {
    const opts = normalizeOptions(options);
    const leagues = new Map();
    const patchesByLeague = new Map();
    const teamsByLeague = new Map();
    const teamGames = new Map();
    const champions = new Set();

    for (const game of games) {
      if (!TARGET_LEAGUES.includes(game.league) || !Number.isFinite(game.totalKills)) continue;
      if (!leagues.has(game.league)) leagues.set(game.league, []);
      leagues.get(game.league).push(game);

      if (!patchesByLeague.has(game.league)) patchesByLeague.set(game.league, new Set());
      patchesByLeague.get(game.league).add(game.patch || "ALL");

      if (!teamsByLeague.has(game.league)) teamsByLeague.set(game.league, new Set());
      teamsByLeague.get(game.league).add(game.teamA);
      teamsByLeague.get(game.league).add(game.teamB);

      for (const team of [game.teamA, game.teamB]) {
        const key = `${game.league}::${team}`;
        if (!teamGames.has(key)) teamGames.set(key, []);
        teamGames.get(key).push(game);
      }

      for (const champion of getAllPicks(game)) champions.add(champion);
    }

    for (const list of leagues.values()) list.sort(sortRecent);
    for (const list of teamGames.values()) list.sort(sortRecent);

    const leagueStats = new Map();
    const leagueMeans = new Map();
    const leagueSigmas = new Map();
    for (const [league, list] of leagues) {
      const totals = list.map((game) => game.totalKills);
      const allMean = mean(totals);
      const recentMean = weightedMean(list, (game) => game.totalKills, opts.leagueHalfLife);
      const leagueMean = opts.leagueRecentWeight * recentMean + (1 - opts.leagueRecentWeight) * allMean;
      const sigma = std(totals);
      leagueStats.set(league, { league, n: list.length, allMean, recentMean, mean: leagueMean, sigma });
      leagueMeans.set(league, leagueMean);
      leagueSigmas.set(league, sigma);
    }

    const index = {
      options: opts,
      games,
      leagues,
      leagueStats,
      leagueMeans,
      leagueSigmas,
      patchesByLeague,
      teamsByLeague,
      teamGames,
      championRoleResiduals: new Map(),
    championRoleTotals: new Map(),
    champions: [...champions].sort((a, b) => a.localeCompare(b)),
    offsets: new Map(),
    globalOffset: { value: 0, raw: 0, n: 0 },
  };

    for (const game of games) {
      const pre = predictRaw(index, game, false);
      const residual = game.totalKills - pre.prediction;
      for (const side of ["teamA", "teamB"]) {
        (game.picks?.[side] || []).forEach((champion, indexRole) => {
          const role = ROLES[indexRole] || "UNK";
          addTotalSample(index.championRoleResiduals, index.championRoleTotals, `${role}::${champion}`, residual, game.totalKills);
        });
      }
    }

    return index;
  }

  function getLeagueMean(index, league) {
    return index.leagueStats.get(league)?.mean || mean(index.games.map((game) => game.totalKills));
  }

  function getPatchAdjustment(index, league, patch, leagueMean) {
    const opts = index.options;
    if (!patch || patch === "ALL") return { value: 0, n: 0, raw: 0, mean: leagueMean };
    const list = (index.leagues.get(league) || []).filter((game) => game.patch === patch);
    if (!list.length) return { value: 0, n: 0, raw: 0, mean: leagueMean };
    const patchMean = weightedMean(list.sort(sortRecent), (game) => game.totalKills, opts.leagueHalfLife);
    const raw = patchMean - leagueMean;
    const value = clamp(raw * shrink(list.length, opts.patchShrink) * opts.patchWeight, -opts.patchCap, opts.patchCap);
    return { value, n: list.length, raw, mean: patchMean };
  }

  function getTeamAdjustment(index, league, team, baseline) {
    const opts = index.options;
    const list = (index.teamGames.get(`${league}::${team}`) || []).slice(0, opts.teamWindow);
    if (!list.length) return { team, n: 0, mean: baseline, value: 0, raw: 0 };
    const teamMean = weightedMean(list, (game) => game.totalKills, opts.teamHalfLife);
    const raw = teamMean - baseline;
    const value = clamp(raw * shrink(list.length, opts.teamShrink) * opts.teamWeight, -opts.teamCap, opts.teamCap);
    return { team, n: list.length, mean: teamMean, raw, value };
  }

  function championRoleEffect(index, champion, role) {
    const opts = index.options;
    const key = `${role}::${champion}`;
    const residuals = index.championRoleResiduals.get(key) || [];
    const totals = index.championRoleTotals.get(key) || [];
    if (!residuals.length) return { champion, role, n: 0, average: 0, raw: 0, value: 0 };
    const raw = mean(residuals);
    const value = clamp(raw * shrink(residuals.length, opts.champShrink) * opts.champWeight, -opts.champCap, opts.champCap);
    return { champion, role, n: residuals.length, average: mean(totals), raw, value };
  }

  function getDraftAdjustment(index, game) {
    const opts = index.options;
    const effects = [];
    for (const side of ["teamA", "teamB"]) {
      (game.picks?.[side] || []).forEach((champion, indexRole) => {
        if (!champion) return;
        effects.push(championRoleEffect(index, champion, ROLES[indexRole] || "UNK"));
      });
    }
    const sum = effects.reduce((total, effect) => total + effect.value, 0);
    const value = clamp((sum / 10) * opts.draftWeight, -opts.draftCap, opts.draftCap);
    return { value, effects, count: effects.length };
  }

  /**
   * V2: Ajuste baseado na duração média recente dos dois times.
   * Lógica: se ambos os times jogam partidas longas, esperar mais kills.
   * Usa a duração média do time vs a duração média da liga como diferencial.
   */
  function getDurationAdjustment(index, league, teamAName, teamBName) {
    const opts = index.options;
    // Calcular duração média da liga (só jogos com gameDuration)
    const leagueGames = (index.leagues.get(league) || []).filter((g) => g.gameDuration > 0);
    if (!leagueGames.length) return { value: 0, n: 0, raw: 0, leagueDuration: 0 };
    const leagueDurMean = mean(leagueGames.map((g) => g.gameDuration / 60));

    // Duração média por time
    function teamDuration(team) {
      const list = (index.teamGames.get(`${league}::${team}`) || [])
        .filter((g) => g.gameDuration > 0)
        .slice(0, opts.teamWindow);
      if (!list.length) return { mean: leagueDurMean, n: 0, raw: 0 };
      const durMean = weightedMean(list, (g) => g.gameDuration / 60, opts.teamHalfLife);
      return { mean: durMean, n: list.length, raw: durMean - leagueDurMean };
    }

    const durA = teamDuration(teamAName);
    const durB = teamDuration(teamBName);
    const nMin = Math.min(durA.n, durB.n);

    if (nMin === 0) return { value: 0, n: 0, raw: 0, leagueDuration: leagueDurMean, teamA: durA, teamB: durB };

    // Quanto mais longo que a média, mais kills esperados
    // Usar a média dos desvios dos dois times, convertida em kills
    // Estimativa: cada minuto extra ≈ 0.8 kills extras (baseado em correlação típica)
    const KILLS_PER_EXTRA_MINUTE = 0.8;
    const avgDeviation = (durA.raw + durB.raw) / 2;
    const rawKillsAdj = avgDeviation * KILLS_PER_EXTRA_MINUTE;
    const value = clamp(
      rawKillsAdj * shrink(nMin, opts.durationShrink) * opts.durationWeight,
      -opts.durationCap, opts.durationCap
    );

    return { value, n: nMin, raw: rawKillsAdj, leagueDuration: leagueDurMean, teamA: durA, teamB: durB };
  }

  /**
   * V2: Ajuste baseado no ritmo (kills por minuto) recente dos dois times.
   * Diferente de kills totais: um time pode ter poucos kills totais porque joga rápido,
   * mas ser muito agressivo (alto KPM). Isso separa ritmo de duração.
   */
  function getKpmAdjustment(index, league, teamAName, teamBName, baseline) {
    const opts = index.options;
    const leagueGames = (index.leagues.get(league) || []).filter((g) => g.killsPerMin > 0);
    if (!leagueGames.length) return { value: 0, n: 0, raw: 0, leagueKpm: 0 };
    const leagueKpm = mean(leagueGames.map((g) => g.killsPerMin));

    function teamKpm(team) {
      const list = (index.teamGames.get(`${league}::${team}`) || [])
        .filter((g) => g.killsPerMin > 0)
        .slice(0, opts.teamWindow);
      if (!list.length) return { mean: leagueKpm, n: 0, raw: 0 };
      const kpmMean = weightedMean(list, (g) => g.killsPerMin, opts.teamHalfLife);
      return { mean: kpmMean, n: list.length, raw: kpmMean - leagueKpm };
    }

    const kpmA = teamKpm(teamAName);
    const kpmB = teamKpm(teamBName);
    const nMin = Math.min(kpmA.n, kpmB.n);

    if (nMin === 0) return { value: 0, n: 0, raw: 0, leagueKpm, teamA: kpmA, teamB: kpmB };

    // Converter desvio de KPM em desvio de kills totais
    // Se a duração média da liga é ~30min e KPM devia +0.1, isso = +3 kills
    const leagueDurGames = (index.leagues.get(league) || []).filter((g) => g.gameDuration > 0);
    const avgDurMin = leagueDurGames.length ? mean(leagueDurGames.map((g) => g.gameDuration / 60)) : 30;
    const avgKpmDev = (kpmA.raw + kpmB.raw) / 2;
    const rawKillsAdj = avgKpmDev * avgDurMin;
    const value = clamp(
      rawKillsAdj * shrink(nMin, opts.kpmShrink) * opts.kpmWeight,
      -opts.kpmCap, opts.kpmCap
    );

    return { value, n: nMin, raw: rawKillsAdj, leagueKpm, teamA: kpmA, teamB: kpmB };
  }

  function predictRaw(index, game, includePicks) {
    const leagueMean = getLeagueMean(index, game.league);
    const patch = getPatchAdjustment(index, game.league, game.patch, leagueMean);
    const baseline = leagueMean + patch.value;
    const teamA = getTeamAdjustment(index, game.league, game.teamA, baseline);
    const teamB = getTeamAdjustment(index, game.league, game.teamB, baseline);
    const draft = includePicks ? getDraftAdjustment(index, game) : { value: 0, effects: [], count: 0 };
    const duration = getDurationAdjustment(index, game.league, game.teamA, game.teamB);
    const kpm = getKpmAdjustment(index, game.league, game.teamA, game.teamB, baseline);
    const prediction = baseline + teamA.value + teamB.value + draft.value + duration.value + kpm.value;
    return {
      prediction,
      leagueMean,
      baseline,
      patch,
      teamA,
      teamB,
      draft,
      duration,
      kpm,
      correction: { value: 0, raw: 0, n: 0 },
      sigma: index.leagueStats.get(game.league)?.sigma || DEFAULT_SIGMA,
    };
  }

  function computeOffsets(games, options) {
    const opts = normalizeOptions(options);
    const calibrationIds = new Set();
    const byLeague = new Map();
    for (const game of games) {
      if (!byLeague.has(game.league)) byLeague.set(game.league, []);
      byLeague.get(game.league).push(game);
    }
    for (const list of byLeague.values()) {
      list.sort(sortRecent).slice(0, opts.calibrationWindow).forEach((game) => calibrationIds.add(String(game.id)));
    }

    const coreGames = games.filter((game) => !calibrationIds.has(String(game.id)));
    const coreIndex = buildRawIndex(coreGames, opts);
    const offsets = new Map();
    const globalErrors = [];

    for (const [league, list] of byLeague) {
      const calibration = list.slice(0, opts.calibrationWindow);
      if (!calibration.length || coreGames.filter((game) => game.league === league).length < 20) {
        offsets.set(league, { value: 0, raw: 0, n: 0 });
        continue;
      }
      const errors = calibration.map((game) => game.totalKills - predictRaw(coreIndex, game, true).prediction);
      globalErrors.push(...errors);
      const raw = mean(errors);
      const value = clamp(raw * shrink(errors.length, opts.offsetShrink) * opts.offsetWeight, -opts.offsetCap, opts.offsetCap);
      offsets.set(league, { value, raw, n: errors.length });
    }
    const raw = mean(globalErrors);
    const value = globalErrors.length
      ? clamp(raw * shrink(globalErrors.length, opts.globalOffsetShrink) * opts.globalOffsetWeight, -opts.globalOffsetCap, opts.globalOffsetCap)
      : 0;
    return { offsets, globalOffset: { value, raw, n: globalErrors.length } };
  }

  function buildModel(games, options) {
    const opts = normalizeOptions(options);
    const cleanGames = games.filter((game) => TARGET_LEAGUES.includes(game.league) && Number.isFinite(game.totalKills));
    const index = buildRawIndex(cleanGames, opts);
    const calibration = computeOffsets(cleanGames, opts);
    index.offsets = calibration.offsets;
    index.globalOffset = calibration.globalOffset;
    index.predict = function predict(game, includePicks = true) {
      const result = predictRaw(index, game, includePicks);
      const offset = index.offsets.get(game.league) || { value: 0, raw: 0, n: 0 };
      const globalOffset = index.globalOffset || { value: 0, raw: 0, n: 0 };
      result.prediction += offset.value + globalOffset.value;
      result.correction = {
        value: offset.value + globalOffset.value,
        raw: offset.raw,
        n: offset.n,
        league: offset,
        global: globalOffset,
      };
      return result;
    };
    index.championRoleEffect = (champion, role) => championRoleEffect(index, champion, role);
    return index;
  }

  return {
    TARGET_LEAGUES,
    ROLES,
    DEFAULT_OPTIONS,
    buildModel,
    buildRawIndex,
    predictRaw,
    sortRecent,
    mean,
    std,
    shrink,
  };
});
