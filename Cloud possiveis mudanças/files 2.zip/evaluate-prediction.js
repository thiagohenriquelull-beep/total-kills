/**
 * Fase 1 — Régua honesta de previsão
 *
 * Avalia a qualidade da previsão do modelo, sem nenhuma linha de aposta.
 * Walk-forward: cada jogo é previsto usando apenas jogos anteriores a ele.
 *
 * Inclui uma linha de base ("baseline") que prevê a média recente da liga,
 * para que qualquer melhoria do modelo completo tenha que bater essa referência.
 *
 * Métricas: MAE, bias, RMSE, calibração (±2, ±3, ±5), separadas por liga.
 */

const fs = require("fs");
const path = require("path");
const Model = require("../model-core.js");

const ROOT = path.resolve(__dirname, "..");
const DATA_DIR = path.join(ROOT, "data");
const LEAGUES = Model.TARGET_LEAGUES;
const TESTS_PER_LEAGUE = 15;

// --- helpers ---

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function mean(values) {
  return values.length ? values.reduce((s, v) => s + v, 0) / values.length : 0;
}

function rmse(errors) {
  return Math.sqrt(mean(errors.map((e) => e ** 2)));
}

function round(v, d = 2) {
  return Number(v.toFixed(d));
}

function pct(v) {
  return `${(v * 100).toFixed(1)}%`;
}

function loadGames() {
  const games = [];
  for (const league of LEAGUES) {
    const file = path.join(DATA_DIR, `expanded-${league}.json`);
    if (fs.existsSync(file)) {
      games.push(...readJson(file).games);
    }
  }
  return games;
}

// --- stats ---

function computeStats(rows, getExpected) {
  const signed = rows.map((r) => getExpected(r) - r.actual);
  const abs = signed.map(Math.abs);
  const n = rows.length;
  if (!n) return null;
  return {
    n,
    avgExpected: round(mean(rows.map(getExpected))),
    avgActual: round(mean(rows.map((r) => r.actual))),
    bias: round(mean(signed)),
    mae: round(mean(abs)),
    rmse: round(rmse(signed)),
    within2: round(abs.filter((e) => e <= 2).length / n, 4),
    within3: round(abs.filter((e) => e <= 3).length / n, 4),
    within5: round(abs.filter((e) => e <= 5).length / n, 4),
  };
}

// --- walk-forward ---

function runWalkForward(allGames) {
  const rows = [];

  for (const league of LEAGUES) {
    const chronological = allGames
      .filter((g) => g.league === league)
      .sort(Model.sortRecent)
      .reverse();

    const start = Math.max(0, chronological.length - TESTS_PER_LEAGUE);

    for (let i = start; i < chronological.length; i++) {
      const game = chronological[i];
      const train = chronological.slice(0, i);

      if (train.length < 20) continue; // mínimo para construir modelo

      // Baseline: média simples de kills nos jogos de treino dessa liga
      const trainLeague = train.filter((g) => g.league === league);
      const baselinePred = trainLeague.length ? mean(trainLeague.map((g) => g.totalKills)) : NaN;

      // Modelo completo
      const model = Model.buildModel(train);
      const pre = model.predict(game, false);
      const post = model.predict(game, true);

      rows.push({
        id: game.id,
        league,
        date: game.date,
        patch: game.patch,
        game: `${game.teamA} vs ${game.teamB}`,
        teamA: game.teamA,
        teamB: game.teamB,
        actual: game.totalKills,
        trainGames: train.length,
        baseline: baselinePred,
        pre: pre.prediction,
        post: post.prediction,
        components: {
          leagueMean: pre.leagueMean,
          patchAdj: pre.patch.value,
          teamAAdj: pre.teamA.value,
          teamBAdj: pre.teamB.value,
          draftAdj: post.draft.value,
          correction: pre.correction.value,
          durationAdj: pre.duration.value,
          durationN: pre.duration.n,
          kpmAdj: pre.kpm.value,
          kpmN: pre.kpm.n,
        },
      });
    }
  }

  return rows;
}

// --- report ---

function buildReport(rows) {
  const phases = {
    baseline: (r) => r.baseline,
    preDraft: (r) => r.pre,
    postPicks: (r) => r.post,
  };

  const overall = {};
  for (const [name, getter] of Object.entries(phases)) {
    overall[name] = computeStats(rows, getter);
  }

  const byLeague = LEAGUES.map((league) => {
    const leagueRows = rows.filter((r) => r.league === league);
    const stats = {};
    for (const [name, getter] of Object.entries(phases)) {
      stats[name] = computeStats(leagueRows, getter);
    }
    return { league, ...stats };
  });

  return {
    createdAt: new Date().toISOString(),
    method: "walk-forward",
    testsPerLeague: TESTS_PER_LEAGUE,
    totalTests: rows.length,
    options: Model.DEFAULT_OPTIONS,
    overall,
    byLeague,
  };
}

function buildMarkdown(report, rows) {
  const l = [];
  l.push("# Avaliação de Previsão — Walk-Forward");
  l.push("");
  l.push(`Gerado em: ${report.createdAt}`);
  l.push("Cada jogo foi previsto usando apenas jogos anteriores a ele.");
  l.push("Três modelos comparados: baseline (média da liga), pré-draft (liga+patch+times), pós-picks (pré-draft+draft).");
  l.push("");

  // Geral
  l.push("## Resumo Geral");
  l.push("");
  l.push("| Modelo | Previsão média | Real médio | Bias | MAE | RMSE | ±2 kills | ±3 kills | ±5 kills |");
  l.push("|---|---:|---:|---:|---:|---:|---:|---:|---:|");
  for (const [label, key] of [["Baseline (média liga)", "baseline"], ["Pré-draft", "preDraft"], ["Pós-picks", "postPicks"]]) {
    const s = report.overall[key];
    l.push(`| ${label} | ${s.avgExpected.toFixed(2)} | ${s.avgActual.toFixed(2)} | ${s.bias >= 0 ? "+" : ""}${s.bias.toFixed(2)} | ${s.mae.toFixed(2)} | ${s.rmse.toFixed(2)} | ${pct(s.within2)} | ${pct(s.within3)} | ${pct(s.within5)} |`);
  }
  l.push("");

  // Melhoria vs baseline
  const blMae = report.overall.baseline.mae;
  const preMae = report.overall.preDraft.mae;
  const postMae = report.overall.postPicks.mae;
  l.push(`Melhoria pré-draft vs baseline: MAE ${blMae.toFixed(2)} → ${preMae.toFixed(2)} (${preMae < blMae ? "-" : "+"}${Math.abs(preMae - blMae).toFixed(2)})`);
  l.push(`Melhoria pós-picks vs pré-draft: MAE ${preMae.toFixed(2)} → ${postMae.toFixed(2)} (${postMae < preMae ? "-" : "+"}${Math.abs(postMae - preMae).toFixed(2)})`);
  l.push("");

  // Por liga
  l.push("## Por Liga");
  l.push("");
  l.push("| Liga | Testes | Real médio | Baseline MAE | Pré MAE | Pré bias | Picks MAE | Picks bias | Picks ±3 | Modelo > baseline? | Picks > pré? |");
  l.push("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|");
  for (const item of report.byLeague) {
    const bl = item.baseline;
    const pr = item.preDraft;
    const po = item.postPicks;
    if (!bl || !pr || !po) continue;
    l.push(`| ${item.league} | ${pr.n} | ${pr.avgActual.toFixed(2)} | ${bl.mae.toFixed(2)} | ${pr.mae.toFixed(2)} | ${pr.bias >= 0 ? "+" : ""}${pr.bias.toFixed(2)} | ${po.mae.toFixed(2)} | ${po.bias >= 0 ? "+" : ""}${po.bias.toFixed(2)} | ${pct(po.within3)} | ${pr.mae < bl.mae ? "sim" : "**não**"} | ${po.mae < pr.mae ? "sim" : "não"} |`);
  }
  l.push("");

  // Jogos individuais
  l.push("## Jogos");
  l.push("");
  l.push("| Liga | Jogo | Data | Real | Baseline | Err BL | Pré | Err pré | Picks | Err picks |");
  l.push("|---|---|---|---:|---:|---:|---:|---:|---:|---:|");
  for (const r of rows) {
    const blErr = r.baseline - r.actual;
    const preErr = r.pre - r.actual;
    const postErr = r.post - r.actual;
    l.push(`| ${r.league} | ${r.game} | ${r.date || ""} | ${r.actual} | ${r.baseline.toFixed(1)} | ${blErr >= 0 ? "+" : ""}${blErr.toFixed(1)} | ${r.pre.toFixed(2)} | ${preErr >= 0 ? "+" : ""}${preErr.toFixed(2)} | ${r.post.toFixed(2)} | ${postErr >= 0 ? "+" : ""}${postErr.toFixed(2)} |`);
  }
  l.push("");

  // Componentes
  l.push("## Decomposição dos ajustes");
  l.push("");
  l.push("| Liga | Jogo | Liga base | Patch | Time A | Time B | Draft | Duração | KPM | Correção |");
  l.push("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|");
  for (const r of rows) {
    const c = r.components;
    l.push(`| ${r.league} | ${r.game} | ${c.leagueMean.toFixed(1)} | ${c.patchAdj >= 0 ? "+" : ""}${c.patchAdj.toFixed(2)} | ${c.teamAAdj >= 0 ? "+" : ""}${c.teamAAdj.toFixed(2)} | ${c.teamBAdj >= 0 ? "+" : ""}${c.teamBAdj.toFixed(2)} | ${c.draftAdj >= 0 ? "+" : ""}${c.draftAdj.toFixed(2)} | ${c.durationAdj >= 0 ? "+" : ""}${c.durationAdj.toFixed(2)} | ${c.kpmAdj >= 0 ? "+" : ""}${c.kpmAdj.toFixed(2)} | ${c.correction >= 0 ? "+" : ""}${c.correction.toFixed(2)} |`);
  }
  l.push("");

  return l.join("\n") + "\n";
}

// --- main ---

function main() {
  console.log("Carregando jogos...");
  const games = loadGames();
  console.log(`${games.length} jogos carregados.`);

  console.log("Rodando walk-forward...");
  const rows = runWalkForward(games);
  console.log(`${rows.length} jogos avaliados.`);

  const report = buildReport(rows);

  // Salvar
  const jsonPath = path.join(DATA_DIR, "prediction-evaluation.json");
  const mdPath = path.join(DATA_DIR, "prediction-evaluation.md");
  const csvPath = path.join(DATA_DIR, "prediction-evaluation.csv");

  fs.writeFileSync(jsonPath, JSON.stringify({ report, rows }, null, 2), "utf8");
  fs.writeFileSync(mdPath, buildMarkdown(report, rows), "utf8");

  // CSV
  const headers = ["league", "date", "patch", "game", "actual", "baseline", "pre", "post", "errBaseline", "errPre", "errPost", "trainGames"];
  const csvLines = [headers.join(",")];
  for (const r of rows) {
    csvLines.push([
      r.league, r.date, r.patch, `"${r.game}"`, r.actual,
      round(r.baseline, 1), round(r.pre), round(r.post),
      round(r.baseline - r.actual, 1), round(r.pre - r.actual), round(r.post - r.actual),
      r.trainGames,
    ].join(","));
  }
  fs.writeFileSync(csvPath, csvLines.join("\n") + "\n", "utf8");

  // Sumário no console
  console.log("\n=== RESULTADO ===\n");
  const o = report.overall;
  console.log(`                  Baseline    Pré-draft   Pós-picks`);
  console.log(`  MAE             ${o.baseline.mae.toFixed(2).padStart(7)}     ${o.preDraft.mae.toFixed(2).padStart(7)}     ${o.postPicks.mae.toFixed(2).padStart(7)}`);
  console.log(`  Bias            ${o.baseline.bias >= 0 ? "+" : ""}${o.baseline.bias.toFixed(2).padStart(6)}     ${o.preDraft.bias >= 0 ? "+" : ""}${o.preDraft.bias.toFixed(2).padStart(6)}     ${o.postPicks.bias >= 0 ? "+" : ""}${o.postPicks.bias.toFixed(2).padStart(6)}`);
  console.log(`  RMSE            ${o.baseline.rmse.toFixed(2).padStart(7)}     ${o.preDraft.rmse.toFixed(2).padStart(7)}     ${o.postPicks.rmse.toFixed(2).padStart(7)}`);
  console.log(`  ±3 kills        ${pct(o.baseline.within3).padStart(7)}     ${pct(o.preDraft.within3).padStart(7)}     ${pct(o.postPicks.within3).padStart(7)}`);
  console.log(`  ±5 kills        ${pct(o.baseline.within5).padStart(7)}     ${pct(o.preDraft.within5).padStart(7)}     ${pct(o.postPicks.within5).padStart(7)}`);
  console.log("");
  for (const item of report.byLeague) {
    const pr = item.preDraft;
    const bl = item.baseline;
    if (!pr || !bl) continue;
    const beat = pr.mae < bl.mae ? "✓" : "✗";
    console.log(`  ${item.league.padEnd(6)} baseline=${bl.mae.toFixed(2)} modelo=${pr.mae.toFixed(2)} ${beat}  bias=${pr.bias >= 0 ? "+" : ""}${pr.bias.toFixed(2)}  ±3=${pct(pr.within3)}`);
  }
  console.log("");
}

main();
