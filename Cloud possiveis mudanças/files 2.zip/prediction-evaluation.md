# Avaliação de Previsão — Walk-Forward

Gerado em: 2026-05-26T00:42:03.451Z
Cada jogo foi previsto usando apenas jogos anteriores a ele.
Três modelos comparados: baseline (média da liga), pré-draft (liga+patch+times), pós-picks (pré-draft+draft).

## Resumo Geral

| Modelo | Previsão média | Real médio | Bias | MAE | RMSE | ±2 kills | ±3 kills | ±5 kills |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Baseline (média liga) | 27.99 | 25.84 | +2.15 | 6.91 | 8.56 | 20.0% | 26.7% | 44.0% |
| Pré-draft | 27.12 | 25.84 | +1.28 | 6.72 | 8.51 | 21.3% | 30.7% | 46.7% |
| Pós-picks | 27.12 | 25.84 | +1.28 | 6.72 | 8.51 | 21.3% | 30.7% | 46.7% |

Melhoria pré-draft vs baseline: MAE 6.91 → 6.72 (-0.19)
Melhoria pós-picks vs pré-draft: MAE 6.72 → 6.72 (+0.00)

## Por Liga

| Liga | Testes | Real médio | Baseline MAE | Pré MAE | Pré bias | Picks MAE | Picks bias | Picks ±3 | Modelo > baseline? | Picks > pré? |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| LCK | 15 | 27.80 | 8.60 | 7.71 | -0.59 | 7.71 | -0.59 | 33.3% | sim | não |
| LPL | 15 | 24.53 | 6.82 | 6.52 | +2.06 | 6.52 | +2.06 | 26.7% | sim | não |
| CBLOL | 15 | 25.73 | 4.04 | 4.06 | +0.50 | 4.06 | +0.50 | 46.7% | **não** | não |
| LEC | 15 | 29.27 | 7.16 | 7.06 | +1.12 | 7.06 | +1.12 | 33.3% | sim | não |
| LCS | 15 | 21.87 | 7.94 | 8.26 | +3.29 | 8.26 | +3.29 | 13.3% | **não** | não |

## Jogos

| Liga | Jogo | Data | Real | Baseline | Err BL | Pré | Err pré | Picks | Err picks |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| LCK | HANJIN BRION vs Dplus KIA | 2026-05-21 | 20 | 29.5 | +9.5 | 26.37 | +6.37 | 26.37 | +6.37 |
| LCK | DN SOOPers vs Kiwoom DRX | 2026-05-22 | 22 | 29.4 | +7.4 | 26.79 | +4.79 | 26.79 | +4.79 |
| LCK | Kiwoom DRX vs DN SOOPers | 2026-05-22 | 28 | 29.4 | +1.4 | 26.24 | -1.76 | 26.24 | -1.76 |
| LCK | KT Rolster vs Gen.G | 2026-05-22 | 17 | 29.4 | +12.4 | 27.82 | +10.82 | 27.82 | +10.82 |
| LCK | KT Rolster vs Gen.G | 2026-05-22 | 28 | 29.3 | +1.3 | 27.02 | -0.98 | 27.02 | -0.98 |
| LCK | Dplus KIA vs BNK FearX | 2026-05-23 | 16 | 29.3 | +13.3 | 24.81 | +8.81 | 24.81 | +8.81 |
| LCK | BNK FearX vs Dplus KIA | 2026-05-23 | 37 | 29.2 | -7.8 | 23.19 | -13.81 | 23.19 | -13.81 |
| LCK | Dplus KIA vs BNK FearX | 2026-05-23 | 24 | 29.3 | +5.3 | 24.72 | +0.72 | 24.72 | +0.72 |
| LCK | Hanwha Life Esports vs Nongshim RedForce | 2026-05-23 | 43 | 29.2 | -13.8 | 26.99 | -16.01 | 26.99 | -16.01 |
| LCK | Nongshim RedForce vs Hanwha Life Esports | 2026-05-23 | 54 | 29.3 | -24.7 | 29.60 | -24.40 | 29.60 | -24.40 |
| LCK | Hanwha Life Esports vs Nongshim RedForce | 2026-05-23 | 36 | 29.4 | -6.6 | 33.34 | -2.66 | 33.34 | -2.66 |
| LCK | Gen.G vs DN SOOPers | 2026-05-24 | 25 | 29.5 | +4.5 | 29.02 | +4.02 | 29.02 | +4.02 |
| LCK | Gen.G vs DN SOOPers | 2026-05-24 | 20 | 29.5 | +9.5 | 27.04 | +7.04 | 27.04 | +7.04 |
| LCK | T1 vs HANJIN BRION | 2026-05-24 | 18 | 29.4 | +11.4 | 28.82 | +10.82 | 28.82 | +10.82 |
| LCK | T1 vs HANJIN BRION | 2026-05-24 | 29 | 29.3 | +0.3 | 26.36 | -2.64 | 26.36 | -2.64 |
| LPL | LNG Esports vs Team WE | 2026-05-23 | 24 | 28.5 | +4.5 | 30.69 | +6.69 | 30.69 | +6.69 |
| LPL | LNG Esports vs Team WE | 2026-05-23 | 17 | 28.5 | +11.5 | 29.82 | +12.82 | 29.82 | +12.82 |
| LPL | ThunderTalk Gaming vs Invictus Gaming | 2026-05-23 | 23 | 28.5 | +5.5 | 31.19 | +8.19 | 31.19 | +8.19 |
| LPL | ThunderTalk Gaming vs Invictus Gaming | 2026-05-23 | 33 | 28.4 | -4.6 | 30.71 | -2.29 | 30.71 | -2.29 |
| LPL | Invictus Gaming vs ThunderTalk Gaming | 2026-05-23 | 26 | 28.5 | +2.5 | 30.05 | +4.05 | 30.05 | +4.05 |
| LPL | EDward Gaming vs Ninjas in Pyjamas | 2026-05-24 | 14 | 28.4 | +14.4 | 26.83 | +12.83 | 26.83 | +12.83 |
| LPL | EDward Gaming vs Ninjas in Pyjamas | 2026-05-24 | 37 | 28.4 | -8.6 | 25.27 | -11.73 | 25.27 | -11.73 |
| LPL | Ninjas in Pyjamas vs EDward Gaming | 2026-05-24 | 32 | 28.4 | -3.6 | 27.34 | -4.66 | 27.34 | -4.66 |
| LPL | EDward Gaming vs Ninjas in Pyjamas | 2026-05-24 | 32 | 28.4 | -3.6 | 26.85 | -5.15 | 26.85 | -5.15 |
| LPL | Ninjas in Pyjamas vs EDward Gaming | 2026-05-24 | 27 | 28.5 | +1.5 | 27.49 | +0.49 | 27.49 | +0.49 |
| LPL | LGD Gaming vs Weibo Gaming | 2026-05-24 | 15 | 28.4 | +13.4 | 24.80 | +9.80 | 24.80 | +9.80 |
| LPL | Weibo Gaming vs LGD Gaming | 2026-05-24 | 15 | 28.4 | +13.4 | 21.94 | +6.94 | 21.94 | +6.94 |
| LPL | LGD Gaming vs Weibo Gaming | 2026-05-24 | 30 | 28.4 | -1.6 | 20.39 | -9.61 | 20.39 | -9.61 |
| LPL | Weibo Gaming vs LGD Gaming | 2026-05-24 | 22 | 28.4 | +6.4 | 23.05 | +1.05 | 23.05 | +1.05 |
| LPL | Weibo Gaming vs LGD Gaming | 2026-05-24 | 21 | 28.3 | +7.3 | 22.44 | +1.44 | 22.44 | +1.44 |
| CBLOL | Fluxo W7M vs RED Canids | 2026-05-16 | 24 | 28.5 | +4.5 | 29.33 | +5.33 | 29.33 | +5.33 |
| CBLOL | RED Canids vs Fluxo W7M | 2026-05-16 | 18 | 28.5 | +10.5 | 29.36 | +11.36 | 29.36 | +11.36 |
| CBLOL | RED Canids vs Fluxo W7M | 2026-05-16 | 25 | 28.4 | +3.4 | 26.87 | +1.87 | 26.87 | +1.87 |
| CBLOL | LOUD vs FURIA | 2026-05-17 | 26 | 28.4 | +2.4 | 25.50 | -0.50 | 25.50 | -0.50 |
| CBLOL | FURIA vs LOUD | 2026-05-17 | 23 | 28.3 | +5.3 | 24.30 | +1.30 | 24.30 | +1.30 |
| CBLOL | FURIA vs LOUD | 2026-05-17 | 26 | 28.3 | +2.3 | 24.60 | -1.40 | 24.60 | -1.40 |
| CBLOL | Los Grandes vs Vivo Keyd Stars | 2026-05-23 | 32 | 28.3 | -3.7 | 24.73 | -7.27 | 24.73 | -7.27 |
| CBLOL | Los Grandes vs Vivo Keyd Stars | 2026-05-23 | 29 | 28.3 | -0.7 | 25.24 | -3.76 | 25.24 | -3.76 |
| CBLOL | Los Grandes vs Vivo Keyd Stars | 2026-05-23 | 29 | 28.3 | -0.7 | 26.14 | -2.86 | 26.14 | -2.86 |
| CBLOL | FURIA vs RED Canids | 2026-05-24 | 24 | 28.3 | +4.3 | 27.00 | +3.00 | 27.00 | +3.00 |
| CBLOL | FURIA vs RED Canids | 2026-05-24 | 25 | 28.3 | +3.3 | 27.35 | +2.35 | 27.35 | +2.35 |
| CBLOL | FURIA vs RED Canids | 2026-05-24 | 21 | 28.3 | +7.3 | 26.10 | +5.10 | 26.10 | +5.10 |
| CBLOL | Los Grandes vs LOUD | 2026-05-25 | 28 | 28.2 | +0.2 | 25.93 | -2.07 | 25.93 | -2.07 |
| CBLOL | Los Grandes vs LOUD | 2026-05-25 | 22 | 28.2 | +6.2 | 25.91 | +3.91 | 25.91 | +3.91 |
| CBLOL | Los Grandes vs LOUD | 2026-05-25 | 34 | 28.2 | -5.8 | 25.14 | -8.86 | 25.14 | -8.86 |
| LEC | G2 Esports vs Movistar KOI | 2026-05-10 | 27 | 27.6 | +0.6 | 30.74 | +3.74 | 30.74 | +3.74 |
| LEC | Movistar KOI vs G2 Esports | 2026-05-10 | 32 | 27.6 | -4.4 | 30.63 | -1.37 | 30.63 | -1.37 |
| LEC | G2 Esports vs Movistar KOI | 2026-05-10 | 44 | 27.6 | -16.4 | 31.34 | -12.66 | 31.34 | -12.66 |
| LEC | G2 Esports vs Karmine Corp | 2026-05-23 | 38 | 27.7 | -10.3 | 31.46 | -6.54 | 31.46 | -6.54 |
| LEC | G2 Esports vs Karmine Corp | 2026-05-23 | 12 | 27.8 | +15.8 | 34.23 | +22.23 | 34.23 | +22.23 |
| LEC | G2 Esports vs Karmine Corp | 2026-05-23 | 36 | 27.7 | -8.3 | 30.50 | -5.50 | 30.50 | -5.50 |
| LEC | G2 Esports vs Karmine Corp | 2026-05-23 | 33 | 27.7 | -5.3 | 31.32 | -1.68 | 31.32 | -1.68 |
| LEC | Movistar KOI vs Team Vitality | 2026-05-24 | 18 | 27.8 | +9.8 | 31.06 | +13.06 | 31.06 | +13.06 |
| LEC | Movistar KOI vs Team Vitality | 2026-05-24 | 25 | 27.7 | +2.7 | 30.41 | +5.41 | 30.41 | +5.41 |
| LEC | Movistar KOI vs Team Vitality | 2026-05-24 | 17 | 27.7 | +10.7 | 30.29 | +13.29 | 30.29 | +13.29 |
| LEC | Movistar KOI vs G2 Esports | 2026-05-25 | 27 | 27.7 | +0.7 | 27.81 | +0.81 | 27.81 | +0.81 |
| LEC | Movistar KOI vs G2 Esports | 2026-05-25 | 35 | 27.7 | -7.3 | 28.06 | -6.94 | 28.06 | -6.94 |
| LEC | Movistar KOI vs G2 Esports | 2026-05-25 | 26 | 27.7 | +1.7 | 28.87 | +2.87 | 28.87 | +2.87 |
| LEC | G2 Esports vs Movistar KOI | 2026-05-25 | 38 | 27.7 | -10.3 | 29.34 | -8.66 | 29.34 | -8.66 |
| LEC | G2 Esports vs Movistar KOI | 2026-05-25 | 31 | 27.7 | -3.3 | 29.81 | -1.19 | 29.81 | -1.19 |
| LCS | Dignitas vs Sentinels | 2026-05-17 | 10 | 26.4 | +16.4 | 26.29 | +16.29 | 26.29 | +16.29 |
| LCS | Sentinels vs Dignitas | 2026-05-17 | 26 | 26.3 | +0.3 | 24.13 | -1.87 | 24.13 | -1.87 |
| LCS | LYON vs FlyQuest | 2026-05-17 | 39 | 26.3 | -12.7 | 27.26 | -11.74 | 27.26 | -11.74 |
| LCS | FlyQuest vs LYON | 2026-05-17 | 16 | 26.4 | +10.4 | 29.67 | +13.67 | 29.67 | +13.67 |
| LCS | LYON vs FlyQuest | 2026-05-17 | 29 | 26.3 | -2.7 | 28.89 | -0.11 | 28.89 | -0.11 |
| LCS | FlyQuest vs Cloud9 | 2026-05-23 | 13 | 26.3 | +13.3 | 27.88 | +14.88 | 27.88 | +14.88 |
| LCS | Cloud9 vs FlyQuest | 2026-05-23 | 22 | 26.2 | +4.2 | 25.66 | +3.66 | 25.66 | +3.66 |
| LCS | Cloud9 vs FlyQuest | 2026-05-23 | 17 | 26.2 | +9.2 | 23.98 | +6.98 | 23.98 | +6.98 |
| LCS | FlyQuest vs Cloud9 | 2026-05-23 | 28 | 26.1 | -1.9 | 23.29 | -4.71 | 23.29 | -4.71 |
| LCS | FlyQuest vs Cloud9 | 2026-05-23 | 27 | 26.1 | -0.9 | 23.92 | -3.08 | 23.92 | -3.08 |
| LCS | Team Liquid vs LYON | 2026-05-24 | 13 | 26.1 | +13.1 | 25.37 | +12.37 | 25.37 | +12.37 |
| LCS | Team Liquid vs LYON | 2026-05-24 | 26 | 26.0 | +0.0 | 22.66 | -3.34 | 22.66 | -3.34 |
| LCS | LYON vs Team Liquid | 2026-05-24 | 35 | 26.0 | -9.0 | 22.62 | -12.38 | 22.62 | -12.38 |
| LCS | LYON vs Team Liquid | 2026-05-24 | 13 | 26.1 | +13.1 | 24.25 | +11.25 | 24.25 | +11.25 |
| LCS | Team Liquid vs LYON | 2026-05-24 | 14 | 26.0 | +12.0 | 21.51 | +7.51 | 21.51 | +7.51 |

## Decomposição dos ajustes

| Liga | Jogo | Liga base | Patch | Time A | Time B | Draft | Duração | KPM | Correção |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| LCK | HANJIN BRION vs Dplus KIA | 29.9 | -0.01 | -0.61 | -1.38 | +0.00 | +0.00 | +0.00 | -1.51 |
| LCK | DN SOOPers vs Kiwoom DRX | 29.0 | -0.03 | -1.26 | +0.80 | +0.00 | +0.00 | +0.00 | -1.76 |
| LCK | Kiwoom DRX vs DN SOOPers | 28.4 | -0.03 | +0.60 | -1.20 | +0.00 | +0.00 | +0.00 | -1.57 |
| LCK | KT Rolster vs Gen.G | 28.4 | -0.03 | +0.38 | +1.44 | +0.00 | +0.00 | +0.00 | -2.38 |
| LCK | KT Rolster vs Gen.G | 27.4 | -0.04 | +0.18 | +1.11 | +0.00 | +0.00 | +0.00 | -1.67 |
| LCK | Dplus KIA vs BNK FearX | 27.5 | -0.04 | -0.92 | +0.55 | +0.00 | +0.00 | +0.00 | -2.29 |
| LCK | BNK FearX vs Dplus KIA | 26.5 | -0.04 | +0.31 | -0.97 | +0.00 | +0.00 | +0.00 | -2.65 |
| LCK | Dplus KIA vs BNK FearX | 27.5 | -0.03 | -0.70 | +0.41 | +0.00 | +0.00 | +0.00 | -2.43 |
| LCK | Hanwha Life Esports vs Nongshim RedForce | 27.2 | -0.03 | +1.32 | +1.12 | +0.00 | +0.00 | +0.00 | -2.59 |
| LCK | Nongshim RedForce vs Hanwha Life Esports | 28.5 | -0.02 | +1.17 | +1.35 | +0.00 | +0.00 | +0.00 | -1.45 |
| LCK | Hanwha Life Esports vs Nongshim RedForce | 30.7 | +0.00 | +1.51 | +1.36 | +0.00 | +0.00 | +0.00 | -0.26 |
| LCK | Gen.G vs DN SOOPers | 31.2 | +0.01 | -0.08 | -1.83 | +0.00 | +0.00 | +0.00 | -0.24 |
| LCK | Gen.G vs DN SOOPers | 30.6 | +0.00 | -0.15 | -1.68 | +0.00 | +0.00 | +0.00 | -1.76 |
| LCK | T1 vs HANJIN BRION | 29.7 | -0.00 | +1.24 | -0.85 | +0.00 | +0.00 | +0.00 | -1.28 |
| LCK | T1 vs HANJIN BRION | 28.7 | -0.01 | +0.90 | -0.90 | +0.00 | +0.00 | +0.00 | -2.34 |
| LPL | LNG Esports vs Team WE | 29.7 | -0.04 | -0.53 | -0.81 | +0.00 | +0.00 | +0.00 | +2.41 |
| LPL | LNG Esports vs Team WE | 29.2 | -0.05 | -0.53 | -0.78 | +0.00 | +0.00 | +0.00 | +2.00 |
| LPL | ThunderTalk Gaming vs Invictus Gaming | 28.1 | -0.07 | +0.20 | +1.30 | +0.00 | +0.00 | +0.00 | +1.63 |
| LPL | ThunderTalk Gaming vs Invictus Gaming | 27.7 | -0.07 | +0.10 | +1.04 | +0.00 | +0.00 | +0.00 | +1.94 |
| LPL | Invictus Gaming vs ThunderTalk Gaming | 28.2 | -0.05 | +0.98 | +0.16 | +0.00 | +0.00 | +0.00 | +0.81 |
| LPL | EDward Gaming vs Ninjas in Pyjamas | 28.0 | -0.05 | -0.56 | -0.20 | +0.00 | +0.00 | +0.00 | -0.33 |
| LPL | EDward Gaming vs Ninjas in Pyjamas | 26.8 | -0.07 | -0.68 | -0.36 | +0.00 | +0.00 | +0.00 | -0.40 |
| LPL | Ninjas in Pyjamas vs EDward Gaming | 27.7 | -0.05 | -0.19 | -0.47 | +0.00 | +0.00 | +0.00 | +0.37 |
| LPL | EDward Gaming vs Ninjas in Pyjamas | 28.0 | -0.04 | -0.35 | -0.11 | +0.00 | +0.00 | +0.00 | -0.70 |
| LPL | Ninjas in Pyjamas vs EDward Gaming | 28.4 | -0.03 | -0.06 | -0.26 | +0.00 | +0.00 | +0.00 | -0.54 |
| LPL | LGD Gaming vs Weibo Gaming | 28.3 | -0.03 | -1.17 | -0.87 | +0.00 | +0.00 | +0.00 | -1.40 |
| LPL | Weibo Gaming vs LGD Gaming | 27.1 | -0.04 | -0.94 | -1.21 | +0.00 | +0.00 | +0.00 | -3.01 |
| LPL | LGD Gaming vs Weibo Gaming | 26.1 | -0.05 | -1.24 | -0.98 | +0.00 | +0.00 | +0.00 | -3.46 |
| LPL | Weibo Gaming vs LGD Gaming | 26.5 | -0.04 | -0.80 | -1.04 | +0.00 | +0.00 | +0.00 | -1.53 |
| LPL | Weibo Gaming vs LGD Gaming | 26.1 | -0.04 | -0.76 | -0.98 | +0.00 | +0.00 | +0.00 | -1.88 |
| CBLOL | Fluxo W7M vs RED Canids | 28.6 | +0.04 | +0.18 | +0.82 | +0.00 | +0.00 | +0.00 | -0.26 |
| CBLOL | RED Canids vs Fluxo W7M | 28.2 | +0.02 | +0.66 | +0.10 | +0.00 | +0.00 | +0.00 | +0.42 |
| CBLOL | RED Canids vs Fluxo W7M | 27.3 | -0.01 | +0.45 | -0.06 | +0.00 | +0.00 | +0.00 | -0.81 |
| CBLOL | LOUD vs FURIA | 27.1 | -0.01 | -0.30 | +0.42 | +0.00 | +0.00 | +0.00 | -1.72 |
| CBLOL | FURIA vs LOUD | 27.0 | -0.01 | +0.35 | -0.29 | +0.00 | +0.00 | +0.00 | -2.78 |
| CBLOL | FURIA vs LOUD | 26.7 | -0.02 | +0.26 | -0.30 | +0.00 | +0.00 | +0.00 | -2.04 |
| CBLOL | Los Grandes vs Vivo Keyd Stars | 26.7 | -0.02 | +0.49 | +0.01 | +0.00 | +0.00 | +0.00 | -2.41 |
| CBLOL | Los Grandes vs Vivo Keyd Stars | 27.1 | -0.01 | +0.51 | +0.09 | +0.00 | +0.00 | +0.00 | -2.46 |
| CBLOL | Los Grandes vs Vivo Keyd Stars | 27.3 | -0.01 | +0.48 | +0.10 | +0.00 | +0.00 | +0.00 | -1.72 |
| CBLOL | FURIA vs RED Canids | 27.4 | -0.00 | -0.02 | +0.27 | +0.00 | +0.00 | +0.00 | -0.69 |
| CBLOL | FURIA vs RED Canids | 27.2 | -0.01 | -0.06 | +0.19 | +0.00 | +0.00 | +0.00 | +0.06 |
| CBLOL | FURIA vs RED Canids | 27.0 | -0.01 | -0.07 | +0.13 | +0.00 | +0.00 | +0.00 | -0.93 |
| CBLOL | Los Grandes vs LOUD | 26.5 | -0.02 | +0.73 | -0.24 | +0.00 | +0.00 | +0.00 | -1.02 |
| CBLOL | Los Grandes vs LOUD | 26.6 | -0.01 | +0.63 | -0.22 | +0.00 | +0.00 | +0.00 | -1.12 |
| CBLOL | Los Grandes vs LOUD | 26.2 | -0.02 | +0.48 | -0.25 | +0.00 | +0.00 | +0.00 | -1.32 |
| LEC | G2 Esports vs Movistar KOI | 30.2 | +0.01 | -1.33 | +0.46 | +0.00 | +0.00 | +0.00 | +1.39 |
| LEC | Movistar KOI vs G2 Esports | 29.9 | +0.01 | +0.38 | -1.21 | +0.00 | +0.00 | +0.00 | +1.53 |
| LEC | G2 Esports vs Movistar KOI | 30.1 | +0.01 | -1.00 | +0.37 | +0.00 | +0.00 | +0.00 | +1.89 |
| LEC | G2 Esports vs Karmine Corp | 31.2 | +0.00 | -0.66 | +0.03 | +0.00 | +0.00 | +0.00 | +0.85 |
| LEC | G2 Esports vs Karmine Corp | 31.8 | +0.02 | -0.47 | +0.11 | +0.00 | +0.00 | +0.00 | +2.78 |
| LEC | G2 Esports vs Karmine Corp | 30.1 | -0.03 | -0.65 | -0.15 | +0.00 | +0.00 | +0.00 | +1.27 |
| LEC | G2 Esports vs Karmine Corp | 30.5 | -0.02 | -0.50 | -0.06 | +0.00 | +0.00 | +0.00 | +1.35 |
| LEC | Movistar KOI vs Team Vitality | 30.7 | -0.01 | +0.69 | -0.87 | +0.00 | +0.00 | +0.00 | +0.52 |
| LEC | Movistar KOI vs Team Vitality | 29.6 | -0.03 | +0.46 | -0.92 | +0.00 | +0.00 | +0.00 | +1.28 |
| LEC | Movistar KOI vs Team Vitality | 29.2 | -0.04 | +0.34 | -0.87 | +0.00 | +0.00 | +0.00 | +1.65 |
| LEC | Movistar KOI vs G2 Esports | 28.2 | -0.06 | +0.15 | +0.37 | +0.00 | +0.00 | +0.00 | -0.81 |
| LEC | Movistar KOI vs G2 Esports | 28.0 | -0.05 | +0.10 | +0.32 | +0.00 | +0.00 | +0.00 | -0.35 |
| LEC | Movistar KOI vs G2 Esports | 28.6 | -0.04 | +0.18 | +0.40 | +0.00 | +0.00 | +0.00 | -0.30 |
| LEC | G2 Esports vs Movistar KOI | 28.4 | -0.04 | +0.32 | +0.12 | +0.00 | +0.00 | +0.00 | +0.54 |
| LEC | G2 Esports vs Movistar KOI | 29.2 | -0.02 | +0.41 | +0.23 | +0.00 | +0.00 | +0.00 | -0.03 |
| LCS | Dignitas vs Sentinels | 28.0 | +0.03 | -0.40 | -0.94 | +0.00 | +0.00 | +0.00 | -0.43 |
| LCS | Sentinels vs Dignitas | 26.5 | -0.01 | -1.05 | -0.59 | +0.00 | +0.00 | +0.00 | -0.70 |
| LCS | LYON vs FlyQuest | 26.4 | -0.01 | +0.39 | +0.44 | +0.00 | +0.00 | +0.00 | +0.01 |
| LCS | FlyQuest vs LYON | 27.5 | +0.01 | +0.56 | +0.52 | +0.00 | +0.00 | +0.00 | +1.08 |
| LCS | LYON vs FlyQuest | 26.5 | -0.01 | +0.32 | +0.34 | +0.00 | +0.00 | +0.00 | +1.73 |
| LCS | FlyQuest vs Cloud9 | 26.7 | -0.00 | +0.33 | -0.06 | +0.00 | +0.00 | +0.00 | +0.89 |
| LCS | Cloud9 vs FlyQuest | 25.5 | -0.02 | -0.23 | +0.12 | +0.00 | +0.00 | +0.00 | +0.25 |
| LCS | Cloud9 vs FlyQuest | 25.2 | -0.02 | -0.24 | +0.04 | +0.00 | +0.00 | +0.00 | -1.04 |
| LCS | FlyQuest vs Cloud9 | 24.5 | -0.03 | -0.08 | -0.32 | +0.00 | +0.00 | +0.00 | -0.82 |
| LCS | FlyQuest vs Cloud9 | 24.9 | -0.02 | -0.03 | -0.24 | +0.00 | +0.00 | +0.00 | -0.64 |
| LCS | Team Liquid vs LYON | 25.1 | -0.02 | +0.45 | +0.79 | +0.00 | +0.00 | +0.00 | -0.89 |
| LCS | Team Liquid vs LYON | 24.0 | -0.03 | +0.24 | +0.52 | +0.00 | +0.00 | +0.00 | -2.09 |
| LCS | LYON vs Team Liquid | 24.2 | -0.03 | +0.47 | +0.23 | +0.00 | +0.00 | +0.00 | -2.27 |
| LCS | LYON vs Team Liquid | 25.2 | -0.02 | +0.56 | +0.35 | +0.00 | +0.00 | +0.00 | -1.79 |
| LCS | Team Liquid vs LYON | 24.1 | -0.02 | +0.14 | +0.31 | +0.00 | +0.00 | +0.00 | -3.04 |

